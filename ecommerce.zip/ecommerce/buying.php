<?php 
session_start();
include("koneksi.php");
$id_produk = $_GET['id'];

if(isset($_SESSION['keranjang'][$id_produk])){
    $_SESSION['keranjang'][$id_produk]+=1;

} else {
    $_SESSION['keranjang'][$id_produk]=1;
}


header ("Location: cart.php")

//   if(isset($_GET['action']) && $_GET['action']=="add"){
//     $id=intval($_GET['id']);
//     if(isset($_SESSION['cart']['$id'])){
//       $_SESSION['cart']['id']['quantity']++;
//     } else {
//     $ambil = $koneksi->query("SELECT * FROM produk WHERE id_produk={$id}");
//     if ($perproduk = $ambil->fetch_assoc()){
//      $_SESSION['cart'][$perproduk['id_produk']]=array(
//        "quantity" => 1,
//        "harga" => $perproduk['harga']
//      );
//     } else {
//       $message = "this produk invalid";
//     }
//   }
//   }


?>