<?php 
session_start();
session_destroy();

echo "<div class='alert alert-info'>anda telah logout</div>";
echo "<script>location='index.php'</script>";
?>