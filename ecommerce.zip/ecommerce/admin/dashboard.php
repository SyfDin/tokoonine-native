<h2>ini dashboard</h2>
<pre><?php print_r($_SESSION); ?></pre>