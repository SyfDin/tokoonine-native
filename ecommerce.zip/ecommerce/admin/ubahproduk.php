<h2>Ubah Produk</h2>
<?php 
include("koneksi.php");
$ambil = $koneksi->query("SELECT * FROM produk WHERE id_produk='$_GET[id]'");
$pecah = $ambil->fetch_assoc();

?>

<div class="container">
<form method="POST" enctype="multipart/form-data" >
    <div class="form-group">
        <label > Nama</label>
        <input type="text" class="form-control" name="nama" value="<?php echo $pecah ['nama'];?>">
    </div>
    <div class="form-group">
        <label >Harga</label>
        <input type="number" name="harga" class="form-control" value="<?php echo $pecah ['harga'];?>">
    </div>
    <div class="form-group">
        <label > Berat</label>
        <input type="number" name="berat" class="form-control" value="<?php echo $pecah ['berat'];?>">
    </div>
    <div class="form-group">
        <label >Stok</label>
        <input type="number" name="stok" class="form-control" value="<?php echo $pecah ['stok'];?>">
    </div>
    <div class="form-group">
        <label >Deskripsi</label>
        <textarea name="deskripsi"  rows="10" class="form-control" ><?php echo $pecah ['deskripsi'];?></textarea>
    </div>
    <div class="form-group">
        <label >Foto</label>
        <input type="file" name="foto" class="form-control">
    </div>
    <button class="btn btn-primary" name="ubah">Ubah</button>

</form>
</div>

<?php 

if(isset($_POST['ubah'])) {
    $namafoto=$_FILES['foto']['name'];
    $lokasifoto =$_FILES['foto']['tmp_name'];
    // jika foto dirubah
    if(!empty($lokasifoto)){
        move_uploaded_file($lokasifoto, "../foto_produk/$namafoto");

        $koneksi->query("UPDATE produk SET nama = '$_POST[nama]', harga = '$_POST[harga]', berat = '$_POST[berat]', stok = '$_POST[stok]', deskripsi = '$_POST[deskripsi]', foto = '$namafoto' 
        WHERE id_produk='$_GET[id]'");
    }
    else {
        $koneksi->query("UPDATE produk SET nama = '$_POST[nama]', harga = '$_POST[harga]', berat = '$_POST[berat]', stok = '$_POST[stok]', deskripsi = '$_POST[deskripsi]' 
        WHERE id_produk='$_GET[id]'");
    }
    echo "<div class='alert alert-info'>Data Telah di Ubah</div>";
echo "<meta http-equiv='refresh' content='1;url=index.php?halaman=produk'>";
}




?>