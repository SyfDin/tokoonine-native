<h2>Masukan produk</h2>
<div class="container">
<form method="POST" enctype="multipart/form-data" >
    <div class="form-group">
        <label > Nama</label>
        <input type="text" class="form-control" name="nama">
    </div>
    <div class="form-group">
        <label >Harga</label>
        <input type="number" name="harga" class="form-control">
    </div>
    <div class="form-group">
        <label > Berat</label>
        <input type="number" name="berat" class="form-control">
    </div>
    <div class="form-group">
        <label >Stok</label>
        <input type="number" name="stok" class="form-control">
    </div>
    <div class="form-group">
        <label >Deskripsi</label>
        <textarea name="deskripsi"  rows="10" class="form-control"></textarea>
    </div>
    <div class="form-group">
        <label >Foto</label>
        <input type="file" name="foto" class="form-control">
    </div>
    <button class="btn btn-primary" name="save">Simpan</button>

</form>
</div>

<?php 
 if(isset($_POST['save']))
{
    $tgl = date("Y-m-d H:i:s");
    $nama = $_FILES['foto']['name'];
    $lokasi = $_FILES['foto']['tmp_name'];

    move_uploaded_file($lokasi, "../foto_produk/".$nama);

    $koneksi->query("INSERT INTO produk (nama, harga, berat, deskripsi, stok, create_date, foto) VALUES 
    ('$_POST[nama]','$_POST[harga]','$_POST[berat]','$_POST[deskripsi]', '$_POST[stok]', '$tgl', '$nama')");

echo "<div class='alert alert-info'>Data Tersimpan</div>";
echo "<meta http-equiv='refresh' content='1;url=index.php?halaman=produk'>";
}


?>